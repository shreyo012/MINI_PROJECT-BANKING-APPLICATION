﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL_Bank
{
    public class BanK
    {
        public int BankId { get; set; }
        public string Act_Number { get; set; }
        public string Password { get; set; }
        public double Balance { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }

    }
    public class BanKContext : DbContext
    {
        public DbSet<BanK> BanKs { get; set; }

        public BanKContext() : base("Server=WKSPUN05GTR1027;Database=Bank_Application;Trusted_Connection=True")
        {

        }
    }

}
