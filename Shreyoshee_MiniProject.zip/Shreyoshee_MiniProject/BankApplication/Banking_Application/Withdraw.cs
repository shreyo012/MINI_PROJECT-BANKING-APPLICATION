﻿using DAL_Banl;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banking_Application
{
    public partial class Withdraw : Form
    {
        public Withdraw()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Transection ob = new Transection();
            Program.PrevBalance = Program.Balance;
            Program.Withdraw = double.Parse(textBox1.Text);
            Program.Balance = ob.Withdraw(Program.Act_Number, double.Parse(textBox1.Text));
            Balance_Withdraw obalance = new Balance_Withdraw();
            obalance.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Bank bank = new Bank();
            bank.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }
    }
}
