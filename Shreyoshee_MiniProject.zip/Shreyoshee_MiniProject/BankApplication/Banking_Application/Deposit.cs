﻿using DAL_Bank;
using DAL_Banl;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Banking_Application
{
    public partial class Deposit : Form
    {
        public Deposit()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Bank bank = new Bank();
            bank.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Transection ob = new Transection();
            Program.PrevBalance = Program.Balance;
            Program.Deposite = double.Parse(textBox1.Text);
            Program.Balance = ob.Deposit(Program.Act_Number, double.Parse(textBox1.Text));
            Program.Act_Char = "D";
            frmBalance obalance = new frmBalance();
            obalance.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }

        private void Deposite_Load(object sender, EventArgs e)
        {
            this.label1.Text = Program.Name;
        }
    }  
}
