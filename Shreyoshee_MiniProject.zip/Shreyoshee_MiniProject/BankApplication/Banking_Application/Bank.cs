﻿using DAL_Bank;
using DAL_Banl;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Banking_Application
{
    public partial class Bank : Form
    {
        public Bank()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Deposit deposite = new Deposit();
            deposite.Show();
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Bank_Load(object sender, EventArgs e)
        {
            this.label2.Text = Program.Name;
            this.lbl_blc.Text = Convert.ToDouble(Program.Balance).ToString();


        }

        private void button3_Click(object sender, EventArgs e)
        {
            Withdraw withDraw = new Withdraw();
            withDraw.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }
    }
}
