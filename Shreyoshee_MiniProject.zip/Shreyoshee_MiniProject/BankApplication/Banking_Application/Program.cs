﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banking_Application
{
    public static class Program
    {
        public static string Name = "";
        public static double Balance=0.00;
        public static double Deposite = 0.00;
        public static double Withdraw = 0.00;
        public static double PrevBalance = 0.00;
        public static string Act_Number = "";
        public static string Act_Char = "D";
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Login());
        }
    }
}
